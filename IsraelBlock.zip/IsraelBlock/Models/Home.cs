﻿namespace IsraelBlock.Models
{
    public class Home
    {
    }
}